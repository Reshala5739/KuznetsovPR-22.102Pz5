﻿using KuznetsovPR_22._102Pz5.Model;
using System.Collections.Generic;
using System.Linq;

namespace KuznetsovPR_22._102Pz5
{
    internal class Helper
    {
        private static Furniture_centerEntities1 _context;

        public static Furniture_centerEntities1 GetContext()
        {
            if (_context == null)
            {
                _context = new Furniture_centerEntities1();
            }
            return _context;
        }
        public void CreateUser(Auth user)
        {
            _context.Auth.Add(user); // Добавление записи нового пользователя
            _context.SaveChanges(); // Сохранение изменений в БД
        }
        public void UpdateUser(Auth user)
        {
            _context.Entry(user).State = System.Data.Entity.EntityState.Modified;
            _context.SaveChanges(); // Сохранение изменений в БД
        }
        public void RemoveUser(int idUser)
        {
            var user = _context.Auth.Find(idUser);
            if (user != null)
            {
                _context.Auth.Remove(user);
                _context.SaveChanges(); // Сохранение изменений в БД
            }
        }
        public List<Auth> FiltrUsers()
        {
            return _context.Auth.Where(x => x.Username.StartsWith("M") || x.Username.StartsWith("A")).ToList();
        }
        public List<Auth> SortUsers()
        {
            return _context.Auth.OrderBy(x => x.Username).ToList();
        }
    }
}
