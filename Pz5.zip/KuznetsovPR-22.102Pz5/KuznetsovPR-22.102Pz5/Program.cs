﻿using Class_Library1;
using KuznetsovPR_22._102Pz5.Model;
using System;
using System.Data.Entity.Validation;

namespace KuznetsovPR_22._102Pz5
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Добавление новой учетной записи пользователя");

            // Ввод логина и пароля
            Console.Write("Введите логин: ");
            string login = Console.ReadLine();

            Console.Write("Введите пароль: ");
            string password = Console.ReadLine();

            // Хеширование пароля
            string hashedPassword = Class1.HashPassword(password);

            // Создаем объект пользователя
            Auth newUser = new Auth
            {
                Username = login,
                Password = hashedPassword
            };

            // Сохраняем нового пользователя в базе данных
            try
            {
                using (Furniture_centerEntities1 db = Helper.GetContext())
                {
                    db.Auth.Add(newUser);
                    db.SaveChanges(); // Сохраняем изменения в базе данных
                }

                Console.WriteLine("\nПользователь успешно добавлен!");
                Console.WriteLine($"Логин: {login}");
                Console.WriteLine($"Хеш пароля: {hashedPassword}");
            }
            catch (DbEntityValidationException ex)
            {
                Console.WriteLine("Ошибка валидации данных:");

                foreach (var validationError in ex.EntityValidationErrors)
                {
                    foreach (var error in validationError.ValidationErrors)
                    {
                        Console.WriteLine($"- Property: {error.PropertyName}, Error: {error.ErrorMessage}");
                    }
                }
            }

            Console.ReadLine();
        }
    }
}
